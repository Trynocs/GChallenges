package com.trynocs.gChallenges.utils.challenge;

import com.trynocs.gChallenges.main;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BossBar;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;
import java.util.Random;

public class AmpelChanger {

    private final JavaPlugin plugin;
    private final NamespacedKey bossBarKey;
    private final Random random;
    private BukkitRunnable colorChangeTask;
    private BossBar bossBar;
    private int currentIndex;
    private FileConfiguration challenge;
    private List<String> colors;

    public AmpelChanger(JavaPlugin plugin) {
        this.plugin = plugin;
        this.bossBarKey = NamespacedKey.minecraft("ampel_bossbar");
        this.random = new Random();
        this.challenge = main.getPlugin().getConfigManager().getCustomConfig("challenge");

        if (challenge.getString("ampel-challenge.enabled").equals("true")) {
            startColorChangeTask();
        }
    }

    public void startColorChangeTask() {
        if (colorChangeTask != null) {
            colorChangeTask.cancel();
        }
        colorChangeTask = new BukkitRunnable() {
            @Override
            public void run() {
                changeColor();
            }
        };
        if (challenge.getString("ampel-challenge.enabled").equals("true")) {
            scheduleNextChange();
        }
    }

    private void scheduleNextChange() {
        long delay = 500L + random.nextInt(800);
        colorChangeTask.runTaskLater(plugin, delay);
    }

    public void changeColor() {

        if (challenge.get("ampel-challenge.color").equals("green")) {
            challenge.set("ampel-challenge.color", "yellow");
            updateBossBar(challenge.getString("ampel-challenge.color"));
            main.getPlugin().getConfigManager().saveCustomConfig("challenge");
            if (challenge.getString("ampel-challenge.enabled").equals("true")) {
                startColorChangeTask();
            }
        }
        if (challenge.get("ampel-challenge.color").equals("yellow")) {
            if (challenge.getString("ampel-challenge.enabled").equals("true")) {
                startRedCountdown();
            }
        }

        if (challenge.get("ampel-challenge.color").equals("red")) {
            challenge.set("ampel-challenge.color", "green");
            updateBossBar(challenge.getString("ampel-challenge.color"));
            main.getPlugin().getConfigManager().saveCustomConfig("challenge");
            if (challenge.getString("ampel-challenge.enabled").equals("true")) {
                startColorChangeTask();
            }
        }
    }

    private void startRedCountdown() {
        new BukkitRunnable() {
            int countdown = 3;

            @Override
            public void run() {
                if (countdown > 0) {
                    if (bossBar != null) {
                        bossBar.setColor(BarColor.RED);
                        bossBar.setTitle("§6Rot in: §c" + countdown);
                        if (countdown == 3) {
                            bossBar.setProgress(25);
                        } else if (countdown == 2) {
                            bossBar.setProgress(50);
                        } else if (countdown == 1) {
                            bossBar.setProgress(75);
                        }
                    }
                    countdown--;
                } else {
                    currentIndex = colors.indexOf("red"); // Set to red
                    updateBossBar(colors.get(currentIndex));
                    challenge.set("ampel-challenge.color", "red");
                    updateBossBar(challenge.getString("ampel-challenge.color"));
                    main.getPlugin().getConfigManager().saveCustomConfig("challenge");
                    if (challenge.getString("ampel-challenge.enabled").equals("true")) {
                        startColorChangeTask();
                    }
                    cancel(); // Stop the countdown task
                }
            }
        }.runTaskTimer(plugin, 0, 20); // Countdown every second
    }

    private void updateBossBar(String color) {
        if (bossBar == null) {
            bossBar = Bukkit.createBossBar(bossBarKey, "", org.bukkit.boss.BarColor.GREEN, org.bukkit.boss.BarStyle.SOLID);
        }

        switch (color) {
            case "green":
                bossBar.setTitle("§6Ampelfarbe: §aGrün");
                bossBar.setColor(org.bukkit.boss.BarColor.GREEN);
                break;
            case "yellow":
                bossBar.setTitle("§6Ampelfarbe: §eGelb");
                bossBar.setColor(org.bukkit.boss.BarColor.YELLOW);
                break;
            case "red":
                bossBar.setTitle("§6Ampelfarbe: §cRot");
                bossBar.setColor(BarColor.RED);
                break;
        }
        bossBar.setVisible(true);
        bossBar.setProgress(1.0);
        for (Player player : Bukkit.getOnlinePlayers()) {
            bossBar.addPlayer(player);
        }
    }

    public String getCurrentColor() {
        return challenge.getString("ampel-challenge.color");
    }

    public void stopTask() {
        if (colorChangeTask != null) {
            colorChangeTask.cancel();
        }
        if (bossBar != null) {
            bossBar.setVisible(false);
        }
    }
}
